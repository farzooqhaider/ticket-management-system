"use client";
import { Box, Typography, IconButton, Avatar } from "@mui/material";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";

export default function AdminTopbar({ title }: { title: string }) {
  return (
    <Box
      sx={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        px: 3,
        py: 1.5,
        borderBottom: "1px solid",
        borderColor: "divider",
      }}
    >
      <Typography variant="body2" color="text.secondary">
        {title}
      </Typography>
      <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
        <IconButton size="small">
          <NotificationsNoneIcon fontSize="small" />
        </IconButton>
        {/* Replace this initial with the real logged-in admin's name once auth/session is wired up */}
        <Avatar sx={{ width: 30, height: 30, fontSize: 13, bgcolor: "primary.main" }}>AD</Avatar>
      </Box>
    </Box>
  );
}
