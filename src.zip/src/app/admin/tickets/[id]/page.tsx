import { notFound, redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getServerSession } from "@/lib/getServerSession";
import { toClientTicket, toClientComment, toClientActivity } from "@/lib/ticketMapper";
import CustomerTicketDetail from "@/components/CustomerTicketDetail";

export default async function TicketDetailPage({ params }: { params: { id: string } }) {
  const session = await getServerSession();
  if (!session) redirect("/login");

  const ticket = await prisma.ticket.findUnique({
    where: { id: params.id },
    include: {
      requester: true,
      assignee: true,
      comments: { orderBy: { createdAt: "asc" }, include: { author: true } },
      activity: { orderBy: { timestamp: "asc" } },
    },
  });

  if (!ticket) notFound();
  // customers can only open tickets they submitted themselves
  if (ticket.requesterId !== session.userId) redirect("/tickets");

  return (
    <CustomerTicketDetail
      ticket={toClientTicket(ticket)}
      initialComments={ticket.comments.filter((c) => !c.isInternal).map(toClientComment)}
      activity={ticket.activity.map(toClientActivity)}
    />
  );
}
