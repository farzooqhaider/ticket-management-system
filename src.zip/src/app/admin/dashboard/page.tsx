import { Box } from "@mui/material";
import AdminSidebar from "@/components/admin/AdminSidebar";
import AdminTopbar from "@/components/admin/AdminTopbar";
import TicketAnalytics from "@/components/admin/TicketAnalytics";
import { mockTickets } from "@/lib/mockTickets";

export default function DashboardPage() {
  return (
    <Box sx={{ display: "flex" }}>
      <Box sx={{ flex: 1 }}>
        <AdminTopbar title="Dashboard" />
        <Box sx={{ p: 3 }}>
          <TicketAnalytics tickets={mockTickets} />
        </Box>
      </Box>
    </Box>
  );
}