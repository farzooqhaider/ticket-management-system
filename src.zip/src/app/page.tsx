import LoginForm from "@/components/forms/Loginform";
import { Box } from "@mui/material";


export default function Home() {
  return (
    <Box sx={{minHeight:"100vh"}}>
      <LoginForm/>
    </Box>
  );
}
