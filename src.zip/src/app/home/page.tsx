import Navbar from "@/components/NavBar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import { Box } from "@mui/material";

export default function Home(){
    return(
        <Box sx={{minHeight:"100vh"}}>
            <Navbar/>
            <Hero/>
            <About/>
        </Box>
    );
}