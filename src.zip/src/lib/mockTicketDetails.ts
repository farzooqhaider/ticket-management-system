import { TicketComment, ActivityLogEntry } from "@/types/ticket";


export const mockComments: Record<string, TicketComment[]> = {
  "1": [
    {
      id: "c1",
      author: "Sara Ahmed",
      message: "I get a 500 error every time I try to log in since this morning.",
      createdAt: "2026-08-10 09:14",
      isInternal: false,
    },
    {
      id: "c2",
      author: "Usman Ali",
      message: "Checked the logs — looks like a database connection timeout. Investigating.",
      createdAt: "2026-08-10 10:02",
      isInternal: true,
    },
  ],
};


export const mockActivityLogs: Record<string, ActivityLogEntry[]> = {
  "1": [
    { id: "a1", action: "Ticket created", actor: "Sara Ahmed", timestamp: "2026-08-10 09:14" },
    { id: "a2", action: "Assigned to Engineering", actor: "Admin", timestamp: "2026-08-10 09:20" },
    { id: "a3", action: "Assigned to Usman Ali", actor: "Admin", timestamp: "2026-08-10 09:21" },
  ],
};

export const agentsByDepartment: Record<string, string[]> = {
  Engineering: ["Usman Ali", "Sara Ahmed"],
  Finance: ["Ayesha Noor"],
  IT: ["Usman Ali"],
  Product: ["Fatima Zahra"],
  Support: ["Ayesha Noor"],
};
